# This file makes the cogs directory a Python package
# This allows the bot to import modules from this directory
